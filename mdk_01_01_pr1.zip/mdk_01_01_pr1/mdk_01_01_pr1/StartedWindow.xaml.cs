﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace mdk_01_01_pr1
{
    /// <summary>
    /// Логика взаимодействия для StartedWindow.xaml
    /// </summary>
    public partial class StartedWindow : Page
    {
        public MainWindow mainWindow;  // ссылка на родителя
        public StartedWindow(MainWindow _mainWindow)
        {
            InitializeComponent();
            mainWindow = _mainWindow; // созранение родиеля
        }

        private void OpenNewStr_Click(object sender, RoutedEventArgs e)
        {
            mainWindow.OpenPage(2);
        }

        private void OpenNewWin_Click(object sender, RoutedEventArgs e)
        {
            new NewWindow().ShowDialog();
        }

        private void FileVV_Click(object sender, RoutedEventArgs e)
        {
            new File().ShowDialog();
        }
    }
}
