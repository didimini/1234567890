﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace mdk_01_01_pr1
{
    /// <summary>
    /// Логика взаимодействия для NewWindow.xaml
    /// </summary>
    public partial class NewWindow : Window
    {
        public List<User> users = new List<User>(); 
        public NewWindow()
        {
            InitializeComponent();

            users.Add(new User("Каримов А.О.", "27.09.1999", "23", "М"));
            users.Add(new User("Шишкин А.О.", "21.04.1998", "24", "М"));
            users.Add(new User("Кучукбаева А.О.", "29.07.1989", "33", "Ж"));
            users.Add(new User("Белова А.О.", "4.10.1995", "27", "Ж"));
            users.Add(new User("Хоробрвх А.О.", "2.11.1996", "26", "М"));
            users.Add(new User("Юкосович А.О.", "7.09.1994", "28", "М"));
            users.Add(new User("Теплоухова А.О.", "26.08.1997", "25", "Ж"));

            LoadUser(users);
        }

        public void LoadUser(List<User> _user)
        {
            userList.Items.Clear();

            for (int i = 0; i < _user.Count; i++)
            {
                userList.Items.Add(_user[i]);
            }
        } 
        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            // создание нового листа где запоминаются по фиьтру ользрватели
            List<User> newUser = new List<User>();

            // выбор пола
            if (genderFilter.SelectedIndex == 0)
            {
                // если нажат муж в CB, и в новый массив заносяться пользователи 
                newUser = users.FindAll(x => x.Gender == "М");
            }
            else
            {
                newUser = users.FindAll(x => x.Gender == "Ж");
            }

            // еси введенно имя в TBзаносятся данные в новый массив 
            newUser = newUser.FindAll(x => x.Name.Contains(nameFilter.Text));

            LoadUser(newUser);
        }
    }

    public class User
    {
        public string Name { get; set; }
        public string Birth { get; set; }
        public string Age { get; set; }
        public string Gender { get; set; }

        public User(string _name, string _birth, string _age, string _gender)
        {
            this.Name = _name;
            this.Birth = _birth;
            this.Age = _age;
            this.Gender = _gender;
        }
    }
}
