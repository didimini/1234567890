﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace mdk_01_01_pr1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            OpenPage(0);
        }

        public void OpenPage(int indexPage)
        {
            if(indexPage == 0)
            {
                frame.Navigate(new StartedWindow(this));
            }
            else if (indexPage == 2)
            {
                frame.Navigate(new LoadPage(this));
            }
        }
    }
}
